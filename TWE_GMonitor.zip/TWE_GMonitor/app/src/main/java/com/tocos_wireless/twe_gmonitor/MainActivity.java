package com.tocos_wireless.twe_gmonitor;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Paint.Align;
import android.hardware.usb.UsbManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.text.format.Time;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.CheckBox;
import android.view.View.OnClickListener;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.Manifest;
import android.content.pm.PackageManager;

import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.chart.PointStyle;
import org.achartengine.model.SeriesSelection;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.model.XYSeries;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;

import jp.ksksue.driver.serial.FTDriver;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Activity;
import android.text.Editable;
import android.view.View;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.util.Log;

import android.os.Environment;
import java.io.File;
import android.media.MediaRecorder;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    FTDriver mSerial;
    final int SERIAL_BAUDRATE = FTDriver.BAUD115200;
    private boolean mStop = false;
    private static final String ACTION_USB_PERMISSION =
            "jp.ksksue.tutorial.USB_PERMISSION";
    private boolean mRunningMainLoop;
    private Handler myHandler,pHandler,myHandler2;
    private Runnable myTask,pTask,myTask2;
    Button start,stop,reset,record,record_stop;
    private LinearLayout mainLayout;

    private static final int REQUEST_MULTI_PERMISSIONS = 101;

    public boolean isAllowedExternalWrite = false;
    public boolean isAllowedExternalRead = false;
    public boolean isAllowedRecord= false;

    private SoundPool soundPool;
    private int sound1, sound2,sound3,sound4,sound5,sound6,sound7,sound8,sound9,sound10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {//MainActivity使ってない
        super.onCreate(savedInstanceState);
        // タイトルを非表示にします。
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);

        // Android 6, API 23以上でパーミッシンの確認
        if(Build.VERSION.SDK_INT >= 23){
            checkMultiPermissions();
        }
        else{
            //
        }


        AudioAttributes audioAttributes = new AudioAttributes.Builder()
                // USAGE_MEDIA
                // USAGE_GAME
                .setUsage(AudioAttributes.USAGE_GAME)
                // CONTENT_TYPE_MUSIC
                // CONTENT_TYPE_SPEECH, etc.
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build();

        soundPool = new SoundPool.Builder()
                .setAudioAttributes(audioAttributes)
                // ストリーム数に応じて
                .setMaxStreams(10)
                .build();


        /*sound1 = soundPool.load(this, R.raw.basdrum, 1);
        sound2 = soundPool.load(this, R.raw.symbal, 1);
        sound3 = soundPool.load(this, R.raw.highhat, 1);
        sound4 = soundPool.load(this, R.raw.snaredum, 1);
        sound5 = soundPool.load(this, R.raw.tom1, 1);*/
        /*sound6 = soundPool.load(this, R.raw.symbal, 1);
        sound7 = soundPool.load(this, R.raw.basdrum, 1);
        sound8 = soundPool.load(this, R.raw.symbal, 1);
        sound9 = soundPool.load(this, R.raw.basdrum, 1);
        sound10 = soundPool.load(this, R.raw.symbal, 1);*/



        // load が終わったか確認する場合
        soundPool.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener() {
            @Override
            public void onLoadComplete(SoundPool soundPool, int sampleId, int status) {
                Log.d("debug","sampleId="+sampleId);
                Log.d("debug","status="+status);
            }
        });

        //currentTime = 0;
        mSerial = new FTDriver((UsbManager) getSystemService(Context.USB_SERVICE));

        // [FTDriver] setPermissionIntent() before begin()
        PendingIntent permissionIntent = PendingIntent.getBroadcast(this, 0, new Intent(
                ACTION_USB_PERMISSION), 0);
        mSerial.setPermissionIntent(permissionIntent);

        //カウントアップ開始

        //X軸用
        myHandler = new Handler();

        //ファイル保存用
        myHandler2 = new Handler();

        pHandler = new Handler();
        pHandler.postDelayed(pTask, 100);

        start =(Button)findViewById(R.id.button1);
        stop =(Button)findViewById(R.id.button2);
        reset =(Button)findViewById(R.id.button3);
        record =(Button)findViewById(R.id.button4);
        record_stop =(Button)findViewById(R.id.button5);

        mainLayout = (LinearLayout)findViewById(R.id.mainLayout);


        // 録音ボタンの処理
        record.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startMediaRecord();

            }
        });

        // 録音ボタンの処理
        record_stop.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                stopRecord();

            }
        });


        //測定開始ボタンの処理
        start.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                myHandler.postDelayed(myTask, 100);
                //myHandler3.postDelayed(myTask3, 100);
                mStop = false;
                if (mSerial.begin(SERIAL_BAUDRATE)) {
                    mainloop();
                    start.setEnabled(false);
                    stop.setEnabled(true);
                }
            }
        });

    }

    private void mainloop() {
        mRunningMainLoop = true;
        new Thread(mLoop).start();
    }

    private Runnable mLoop = new Runnable() {
        @Override
        public void run() {

            int i, len;

            // [FTDriver] Create Read Buffer
            byte[] rbuf = new byte[4096]; // 1byte <--slow-- [Transfer Speed] --fast--> 4096 byte
            while (true) {
                    // [FTDriver] Read from USB serial
                    len = mSerial.read(rbuf);
                    rbuf[len] = 0;
                    String str1 = new String(rbuf);


                    if (len > 72) {

                        String[] new_str1 = str1.split(";", 0);
                        int youso = new_str1.length;
                    }

            }
        }
    };


    protected void voice(String id) {
        if(id.equalsIgnoreCase("10F5F19")){
            //soundPool.play(sound1, 1.0f, 1.0f, 0, 0, 1);
            //startPlay();//録音
        }else if(id.equalsIgnoreCase("10F5EFC")){//10F5EFC
            //soundPool.play(sound2, 1.0f, 1.0f, 0, 0, 1);
        }else{
            //soundPool.play(sound1, 1.0f, 1.0f, 0, 0, 1);
            //soundPool.play(sound2, 1.0f, 1.0f, 0, 0, 1);
        }
    }

    //録音
    private MediaRecorder mediarecorder; //録音用のメディアレコーダークラス

    static final String filePath = Environment.getExternalStorageDirectory() + "/sample.wav"; //録音用のファイルパス

    private void startMediaRecord(){

        try{
            File mediafile = new File(filePath);
            if(mediafile.exists()) {
                //ファイルが存在する場合は削除する
                mediafile.delete();
            }
            mediafile = null;
            mediarecorder = new MediaRecorder();
            //マイクからの音声を録音する
            mediarecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            //ファイルへの出力フォーマット DEFAULTにするとwavが扱えるはず
            mediarecorder.setOutputFormat(MediaRecorder.OutputFormat.DEFAULT);
            //音声のエンコーダーも合わせてdefaultにする
            mediarecorder.setAudioEncoder(MediaRecorder.AudioEncoder.DEFAULT);
            //ファイルの保存先を指定
            mediarecorder.setOutputFile(filePath);
            //録音の準備をする
            mediarecorder.prepare();
            //録音開始
            mediarecorder.start();
            //Toast.makeText(MainActivity.this, "Start", Toast.LENGTH_SHORT).show();
        } catch(Exception e){
            e.printStackTrace();
        }
    }
   

    //停止
    private void stopRecord(){
        if(mediarecorder == null){
            Toast.makeText(MainActivity.this, "mediarecorder = null", Toast.LENGTH_SHORT).show();
        }else{
            try{
                //録音停止
                mediarecorder.stop();
                mediarecorder.reset();
                mediarecorder.release();
                //Toast.makeText(MainActivity.this, "End", Toast.LENGTH_SHORT).show();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    private MediaPlayer mp; //再生用のメディアレコーダークラス

    private  void startPlay(){
        try {
            mp = new MediaPlayer();
            mp.setDataSource(filePath);
            mp.prepare();
            mp.start();
        }catch (Exception e){
            e.printStackTrace();
        }
    }



    @Override
    protected void onPause() {//戻ったときに音解放
        super.onPause();
        soundPool.release();
    }



    // 許可の確認
    private  void checkMultiPermissions(){
        int permissionExtREAD = ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE);
        int permissionExtWRITE = ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int permissionRECORD = ContextCompat.checkSelfPermission(this,
                Manifest.permission.RECORD_AUDIO);

        List<String> reqPermissions = new ArrayList<>();

        // permission が許可されているか確認
        if (permissionExtREAD == PackageManager.PERMISSION_GRANTED) {
            isAllowedExternalRead = true;
            Log.d("debug","permissionLocation:GRANTED");
        }
        else{
            reqPermissions.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (permissionExtWRITE == PackageManager.PERMISSION_GRANTED) {
            isAllowedExternalWrite = true;
            Log.d("debug","permissionExtStorage:GRANTED");
        }
        else{
            reqPermissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (permissionRECORD == PackageManager.PERMISSION_GRANTED) {
            isAllowedRecord = true;
            Log.d("debug","permissionExtStorage:GRANTED");
        }
        else{
            reqPermissions.add(Manifest.permission.RECORD_AUDIO);
        }
        if (!reqPermissions.isEmpty()) {
            ActivityCompat.requestPermissions(this,
                    reqPermissions.toArray(new String[reqPermissions.size()]),
                    REQUEST_MULTI_PERMISSIONS);
        }
        else{
            //startLocationActivity();
        }
    }

    // 結果の受け取り
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions, @NonNull int[] grantResults) {

        if (requestCode == REQUEST_MULTI_PERMISSIONS) {
            if (grantResults.length > 0) {
                for (int i = 0; i < permissions.length; i++) {
                    if (permissions[i].
                            equals(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                        if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                            isAllowedExternalWrite = true;
                        } else {
                            // それでも拒否された時の対応
                            Toast toast = Toast.makeText(this,
                                    "外部書込の許可がないので書き込みできません", Toast.LENGTH_SHORT);
                            toast.show();
                        }
                    } else if (permissions[i].
                            equals(Manifest.permission.READ_EXTERNAL_STORAGE)) {
                        if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                            isAllowedExternalRead = true;
                        } else {
                            // それでも拒否された時の対応
                            Toast toast = Toast.makeText(this,
                                    "外部読み込みの許可がないので読み込みできません", Toast.LENGTH_SHORT);
                            toast.show();
                        }
                    } else if (permissions[i].
                            equals(Manifest.permission.RECORD_AUDIO)) {
                        if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                            isAllowedRecord = true;
                        } else {
                            // それでも拒否された時の対応
                            Toast toast = Toast.makeText(this,
                                    "録音の許可がないので録音できません", Toast.LENGTH_SHORT);
                            toast.show();
                        }
                    }
                }

            }
        }
    }


}