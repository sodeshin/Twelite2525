package com.tocos_wireless.twe_gmonitor;

import android.os.Bundle;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.app.Activity;
import android.os.Handler;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.hardware.usb.UsbManager;
import android.media.MediaPlayer;
import android.support.v4.app.ActivityCompat;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import jp.ksksue.driver.serial.FTDriver;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.util.Log;
import android.os.Environment;
import java.io.File;
import android.media.MediaRecorder;
import java.util.ArrayList;
import java.util.List;

public class navigationActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    int buttonSelect=1;
    int soundSelect1=0,soundSelect2=0,soundSelect3=0,soundSelect4=0;
    FTDriver mSerial;
    final int SERIAL_BAUDRATE = FTDriver.BAUD115200;
    private boolean mStop = false;
    private static final String ACTION_USB_PERMISSION =
            "jp.ksksue.tutorial.USB_PERMISSION";
    private boolean mRunningMainLoop;
    private Handler myHandler,pHandler,myHandler2;
    private Runnable myTask,pTask,myTask2;
    Button start,stop,reset,record,record_stop;
    private LinearLayout mainLayout;

    private static final int REQUEST_MULTI_PERMISSIONS = 101;

    public boolean isAllowedExternalWrite = false;
    public boolean isAllowedExternalRead = false;
    public boolean isAllowedRecord= false;

    private SoundPool soundPool;
    private int sound1, sound2,sound3,sound4;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigation);
        //Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);

        Button fab1 = (Button) findViewById(R.id.fab1);//ノーマルボタン
        //FloatingActionButton fab1 = (FloatingActionButton) findViewById(R.id.fab1);
        fab1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
                buttonSelect=1;

                drawer.openDrawer(GravityCompat.START);//drwawer出す
            }
        });

        Button fab2 = (Button) findViewById(R.id.fab2);
        fab2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
                buttonSelect=2;
                drawer.openDrawer(GravityCompat.START);//drwawer出す
            }
        });

        Button fab3 = (Button) findViewById(R.id.fab3);
        fab3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
                buttonSelect=3;
                drawer.openDrawer(GravityCompat.START);//drwawer出す
            }
        });

        Button fab4 = (Button) findViewById(R.id.fab4);
        fab4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
                buttonSelect=4;
                drawer.openDrawer(GravityCompat.START);//drwawer出す
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        //ツールバー消去
        /*ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();*/

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);



        // タイトルを非表示にします。
        //requestWindowFeature(Window.FEATURE_NO_TITLE);
        //setContentView(R.layout.activity_main);//////

        // Android 6, API 23以上でパーミッシンの確認
        if(Build.VERSION.SDK_INT >= 23){
            checkMultiPermissions();
        }
        else{
            //
        }


        AudioAttributes audioAttributes = new AudioAttributes.Builder()
                // USAGE_MEDIA
                // USAGE_GAME
                .setUsage(AudioAttributes.USAGE_GAME)
                // CONTENT_TYPE_MUSIC
                // CONTENT_TYPE_SPEECH, etc.
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build();

        soundPool = new SoundPool.Builder()
                .setAudioAttributes(audioAttributes)
                // ストリーム数に応じて
                .setMaxStreams(10)
                .build();

        //初期音
        sound1 = soundPool.load(this, R.raw.bassdrum, 1);
        sound2 = soundPool.load(this, R.raw.symbal, 1);
        sound3 = soundPool.load(this, R.raw.highhat, 1);
        sound4 = soundPool.load(this, R.raw.snaredrum, 1);



        // load が終わったか確認する場合
        soundPool.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener() {
            @Override
            public void onLoadComplete(SoundPool soundPool, int sampleId, int status) {
                Log.d("debug","sampleId="+sampleId);
                Log.d("debug","status="+status);
            }
        });

        //currentTime = 0;
        mSerial = new FTDriver((UsbManager) getSystemService(Context.USB_SERVICE));

        // [FTDriver] setPermissionIntent() before begin()
        PendingIntent permissionIntent = PendingIntent.getBroadcast(this, 0, new Intent(
                ACTION_USB_PERMISSION), 0);
        mSerial.setPermissionIntent(permissionIntent);

        //カウントアップ開始

        //X軸用
        myHandler = new Handler();

        //ファイル保存用
        myHandler2 = new Handler();

        pHandler = new Handler();
        pHandler.postDelayed(pTask, 100);

        start =(Button)findViewById(R.id.button1);
        //stop =(Button)findViewById(R.id.button2);
        //reset =(Button)findViewById(R.id.button3);
        record =(Button)findViewById(R.id.button4);
        record_stop =(Button)findViewById(R.id.button5);

        mainLayout = (LinearLayout)findViewById(R.id.mainLayout);



        //測定開始ボタンの処理
        start.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //myHandler.postDelayed(myTask, 100);
                //myHandler3.postDelayed(myTask3, 100);
                //mStop = false;
                if (mSerial.begin(SERIAL_BAUDRATE)) {
                    mainloop();
                    start.setEnabled(false);
                    //stop.setEnabled(true);
                }
            }
        });

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.navigation, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            switch (buttonSelect){
                case 1:
                    soundSelect1=0;
                    //ボタンのテキスト変更
                    Button fab1 = (Button) findViewById(R.id.fab1);
                    fab1.setText("1");
                    //音変更
                    sound1 = soundPool.load(this, R.raw.bassdrum, 1);

                    break;
                case 2:
                    soundSelect2=0;
                    Button fab2 = (Button) findViewById(R.id.fab2);
                    fab2.setText("1");
                    sound2 = soundPool.load(this, R.raw.bassdrum, 1);
                    break;
                case 3:
                    soundSelect3=0;
                    Button fab3 = (Button) findViewById(R.id.fab3);
                    fab3.setText("1");
                    sound3 = soundPool.load(this, R.raw.bassdrum, 1);
                    break;
                case 4:
                    soundSelect4=0;
                    Button fab4 = (Button) findViewById(R.id.fab4);
                    fab4.setText("1");
                    sound4 = soundPool.load(this, R.raw.bassdrum, 1);
                    break;

            }
        } else if (id == R.id.nav_gallery) {
            switch (buttonSelect) {
                case 1:
                    soundSelect1=0;
                    //ボタンのテキスト変更
                    Button fab1 = (Button) findViewById(R.id.fab1);
                    fab1.setText("2");
                    //音変更
                    sound1 = soundPool.load(this, R.raw.symbal, 1);

                    break;
                case 2:
                    soundSelect2=0;
                    Button fab2 = (Button) findViewById(R.id.fab2);
                    fab2.setText("2");
                    sound2 = soundPool.load(this, R.raw.symbal, 1);
                    break;
                case 3:
                    soundSelect3=0;
                    Button fab3 = (Button) findViewById(R.id.fab3);
                    fab3.setText("2");
                    sound3 = soundPool.load(this, R.raw.symbal, 1);
                    break;
                case 4:
                    soundSelect4=0;
                    Button fab4 = (Button) findViewById(R.id.fab4);
                    fab4.setText("2");
                    sound4 = soundPool.load(this, R.raw.symbal, 1);
                    break;
            }

        } else if (id == R.id.nav_slideshow) {
            switch (buttonSelect) {
                case 1:
                    soundSelect1=0;
                    //ボタンのテキスト変更
                    Button fab1 = (Button) findViewById(R.id.fab1);
                    fab1.setText("3");
                    //音変更
                    sound1 = soundPool.load(this, R.raw.highhat, 1);

                    break;
                case 2:
                    soundSelect2=0;
                    Button fab2 = (Button) findViewById(R.id.fab2);
                    fab2.setText("3");
                    sound2 = soundPool.load(this, R.raw.highhat, 1);
                    break;
                case 3:
                    soundSelect3=0;
                    Button fab3 = (Button) findViewById(R.id.fab3);
                    fab3.setText("3");
                    sound3 = soundPool.load(this, R.raw.highhat, 1);
                    break;
                case 4:
                    soundSelect4=0;
                    Button fab4 = (Button) findViewById(R.id.fab4);
                    fab4.setText("3");
                    sound4 = soundPool.load(this, R.raw.highhat, 1);
                    break;
            }

        } else if (id == R.id.nav_manage) {
            switch (buttonSelect) {
                case 1:
                    soundSelect1=0;
                    //ボタンのテキスト変更
                    Button fab1 = (Button) findViewById(R.id.fab1);
                    fab1.setText("4");
                    //音変更
                    sound1 = soundPool.load(this, R.raw.snaredrum, 1);

                    break;
                case 2:
                    soundSelect2=0;
                    Button fab2 = (Button) findViewById(R.id.fab2);
                    fab2.setText("4");
                    sound2 = soundPool.load(this, R.raw.snaredrum, 1);
                    break;
                case 3:
                    soundSelect3=0;
                    Button fab3 = (Button) findViewById(R.id.fab3);
                    fab3.setText("4");
                    sound3 = soundPool.load(this, R.raw.snaredrum, 1);
                    break;
                case 4:
                    soundSelect4=0;
                    Button fab4 = (Button) findViewById(R.id.fab4);
                    fab4.setText("4");
                    sound4 = soundPool.load(this, R.raw.snaredrum, 1);
                    break;
            }

        }else if (id == R.id.nav_5) {
            switch (buttonSelect) {
                case 1:
                    soundSelect1=0;
                    //ボタンのテキスト変更
                    Button fab1 = (Button) findViewById(R.id.fab1);
                    fab1.setText("5");
                    //音変更
                    sound1 = soundPool.load(this, R.raw.tam1, 1);

                    break;
                case 2:
                    soundSelect2=0;
                    Button fab2 = (Button) findViewById(R.id.fab2);
                    fab2.setText("5");
                    sound2 = soundPool.load(this, R.raw.tam1, 1);
                    break;
                case 3:
                    soundSelect3=0;
                    Button fab3 = (Button) findViewById(R.id.fab3);
                    fab3.setText("5");
                    sound3 = soundPool.load(this, R.raw.tam1, 1);
                    break;
                case 4:
                    soundSelect4=0;
                    Button fab4 = (Button) findViewById(R.id.fab4);
                    fab4.setText("5");
                    sound4 = soundPool.load(this, R.raw.tam1, 1);
                    break;
            }

        }else if (id == R.id.nav_6) {
            switch (buttonSelect) {
                case 1:
                    soundSelect1=0;
                    //ボタンのテキスト変更
                    Button fab1 = (Button) findViewById(R.id.fab1);
                    fab1.setText("6");
                    //音変更
                    sound1 = soundPool.load(this, R.raw.tam2, 1);

                    break;
                case 2:
                    soundSelect2=0;
                    Button fab2 = (Button) findViewById(R.id.fab2);
                    fab2.setText("6");
                    sound2 = soundPool.load(this, R.raw.tam2, 1);
                    break;
                case 3:
                    soundSelect3=0;
                    Button fab3 = (Button) findViewById(R.id.fab3);
                    fab3.setText("6");
                    sound3 = soundPool.load(this, R.raw.tam2, 1);
                    break;
                case 4:
                    soundSelect4=0;
                    Button fab4 = (Button) findViewById(R.id.fab4);
                    fab4.setText("6");
                    sound4 = soundPool.load(this, R.raw.tam2, 1);
                    break;
            }

        }else if (id == R.id.nav_7) {
            switch (buttonSelect) {
                case 1:
                    soundSelect1=0;
                    //ボタンのテキスト変更
                    Button fab1 = (Button) findViewById(R.id.fab1);
                    fab1.setText("7");
                    //音変更
                    sound1 = soundPool.load(this, R.raw.tam3, 1);

                    break;
                case 2:
                    soundSelect2=0;
                    Button fab2 = (Button) findViewById(R.id.fab2);
                    fab2.setText("7");
                    sound2 = soundPool.load(this, R.raw.tam3, 1);
                    break;
                case 3:
                    soundSelect3=0;
                    Button fab3 = (Button) findViewById(R.id.fab3);
                    fab3.setText("7");
                    sound3 = soundPool.load(this, R.raw.tam3, 1);
                    break;
                case 4:
                    soundSelect4=0;
                    Button fab4 = (Button) findViewById(R.id.fab4);
                    fab4.setText("7");
                    sound4 = soundPool.load(this, R.raw.tam3, 1);
                    break;
            }

        }else if (id == R.id.nav_8) {
            switch (buttonSelect) {
                case 1:
                    soundSelect1=0;
                    //ボタンのテキスト変更
                    Button fab1 = (Button) findViewById(R.id.fab1);
                    fab1.setText("8");
                    //音変更
                    sound1 = soundPool.load(this, R.raw.eyeshine1, 1);

                    break;
                case 2:
                    soundSelect2=0;
                    Button fab2 = (Button) findViewById(R.id.fab2);
                    fab2.setText("8");
                    sound2 = soundPool.load(this, R.raw.eyeshine1, 1);
                    break;
                case 3:
                    soundSelect3=0;
                    Button fab3 = (Button) findViewById(R.id.fab3);
                    fab3.setText("8");
                    sound3 = soundPool.load(this, R.raw.eyeshine1, 1);
                    break;
                case 4:
                    soundSelect4=0;
                    Button fab4 = (Button) findViewById(R.id.fab4);
                    fab4.setText("8");
                    sound4 = soundPool.load(this, R.raw.eyeshine1, 1);
                    break;
            }

        }else if (id == R.id.nav_9) {
            switch (buttonSelect) {
                case 1:
                    soundSelect1=0;
                    //ボタンのテキスト変更
                    Button fab1 = (Button) findViewById(R.id.fab1);
                    fab1.setText("9");
                    //音変更
                    sound1 = soundPool.load(this, R.raw.boyon, 1);

                    break;
                case 2:
                    soundSelect2=0;
                    Button fab2 = (Button) findViewById(R.id.fab2);
                    fab2.setText("9");
                    sound2 = soundPool.load(this, R.raw.boyon, 1);
                    break;
                case 3:
                    soundSelect3=0;
                    Button fab3 = (Button) findViewById(R.id.fab3);
                    fab3.setText("9");
                    sound3 = soundPool.load(this, R.raw.boyon, 1);
                    break;
                case 4:
                    soundSelect4=0;
                    Button fab4 = (Button) findViewById(R.id.fab4);
                    fab4.setText("9");
                    sound4 = soundPool.load(this, R.raw.boyon, 1);
                    break;
            }

        }else if (id == R.id.nav_10) {
            Toast.makeText(navigationActivity.this, "録音開始", Toast.LENGTH_SHORT).show();
            startMediaRecord();

            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    //ここにかく
                    stopRecord();
                    Toast.makeText(navigationActivity.this, "録音終了", Toast.LENGTH_SHORT).show();
                }
            }, 2000);

            //録音指定
            switch (buttonSelect) {
                case 1:
                    soundSelect1=1;
                    //ボタンのテキスト変更
                    Button fab1 = (Button) findViewById(R.id.fab1);
                    fab1.setText("10");
                    break;
                case 2:
                    soundSelect2=1;
                    Button fab2 = (Button) findViewById(R.id.fab2);
                    fab2.setText("10");
                    break;
                case 3:
                    soundSelect3=1;
                    Button fab3 = (Button) findViewById(R.id.fab3);
                    fab3.setText("10");
                    break;
                case 4:
                    soundSelect4=1;
                    Button fab4 = (Button) findViewById(R.id.fab4);
                    fab4.setText("10");
                    break;
            }

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return false;
    }


    private void mainloop() {
        mRunningMainLoop = true;
        new Thread(mLoop).start();
    }

    private Runnable mLoop =  new Runnable() {
        @Override
        public void run() {
            int i, len;

            // [FTDriver] Create Read Buffer

            while (true) {
                byte[] rbuf = new byte[4096]; // 1byte <--slow-- [Transfer Speed] --fast--> 4096 byte
                // [FTDriver] Read from USB serial
                len = mSerial.read(rbuf);
                rbuf[len] = 0;
                String str1 = new String(rbuf);


                if (len > 36) {

                    String[] new_str1 = str1.split(";", 0);
                    //int youso = new_str1.length;
                    //voice(new_str1[5]);
                    voice(str1);
                }

            }
        }
    };

    protected void voice(String id) {
        if(id.contains("f19") && id.contains("efc") ){
            if((soundSelect1==0)&&(soundSelect2==0)) {
                soundPool.play(sound1, 1.0f, 1.0f, 0, 0, 1);
                soundPool.play(sound2, 1.0f, 1.0f, 0, 0, 1);
            }else if((soundSelect1==0)&&(soundSelect2==1)) {
                soundPool.play(sound1, 1.0f, 1.0f, 0, 0, 1);
                startPlay();//録音鳴らす
            }else if((soundSelect1==1)&&(soundSelect2==0)) {
                soundPool.play(sound2, 1.0f, 1.0f, 0, 0, 1);
                startPlay();//録音鳴らす
            }else if((soundSelect1==1)&&(soundSelect2==1)) {
                startPlay();//録音鳴らす
            }
        }
        else if(id.contains("f19") && id.contains("f0e") ){
            if((soundSelect1==0)&&(soundSelect3==0)) {
                soundPool.play(sound1, 1.0f, 1.0f, 0, 0, 1);
                soundPool.play(sound3, 1.0f, 1.0f, 0, 0, 1);
            }else if((soundSelect1==0)&&(soundSelect3==1)) {
                soundPool.play(sound1, 1.0f, 1.0f, 0, 0, 1);
                startPlay();//録音鳴らす
            }else if((soundSelect1==1)&&(soundSelect3==0)) {
                soundPool.play(sound3, 1.0f, 1.0f, 0, 0, 1);
                startPlay();//録音鳴らす
            }else if((soundSelect1==1)&&(soundSelect3==1)) {
                startPlay();//録音鳴らす
            }
        }
        else if(id.contains("f19") && id.contains("df9") ){
            if((soundSelect1==0)&&(soundSelect4==0)) {
                soundPool.play(sound1, 1.0f, 1.0f, 0, 0, 1);
                soundPool.play(sound4, 1.0f, 1.0f, 0, 0, 1);
            }else if((soundSelect1==0)&&(soundSelect4==1)) {
                soundPool.play(sound1, 1.0f, 1.0f, 0, 0, 1);
                startPlay();//録音鳴らす
            }else if((soundSelect1==1)&&(soundSelect4==0)) {
                soundPool.play(sound4, 1.0f, 1.0f, 0, 0, 1);
                startPlay();//録音鳴らす
            }else if((soundSelect1==1)&&(soundSelect4==1)) {
                startPlay();//録音鳴らす
            }
        }
        else if(id.contains("efc") && id.contains("f0e") ){
            if((soundSelect2==0)&&(soundSelect3==0)) {
                soundPool.play(sound2, 1.0f, 1.0f, 0, 0, 1);
                soundPool.play(sound3, 1.0f, 1.0f, 0, 0, 1);
            }else if((soundSelect2==0)&&(soundSelect3==1)) {
                soundPool.play(sound2, 1.0f, 1.0f, 0, 0, 1);
                startPlay();//録音鳴らす
            }else if((soundSelect2==1)&&(soundSelect3==0)) {
                soundPool.play(sound3, 1.0f, 1.0f, 0, 0, 1);
                startPlay();//録音鳴らす
            }else if((soundSelect2==1)&&(soundSelect3==1)) {
                startPlay();//録音鳴らす
            }
        }
        else if(id.contains("efc") && id.contains("df9") ){
            if((soundSelect2==0)&&(soundSelect4==0)) {
                soundPool.play(sound2, 1.0f, 1.0f, 0, 0, 1);
                soundPool.play(sound4, 1.0f, 1.0f, 0, 0, 1);
            }else if((soundSelect2==0)&&(soundSelect4==1)) {
                soundPool.play(sound2, 1.0f, 1.0f, 0, 0, 1);
                startPlay();//録音鳴らす
            }else if((soundSelect2==1)&&(soundSelect4==0)) {
                soundPool.play(sound4, 1.0f, 1.0f, 0, 0, 1);
                startPlay();//録音鳴らす
            }else if((soundSelect2==1)&&(soundSelect4==1)) {
                startPlay();//録音鳴らす
            }
        }
        else if(id.contains("f0e") && id.contains("df9") ){
            if((soundSelect3==0)&&(soundSelect4==0)) {
                soundPool.play(sound3, 1.0f, 1.0f, 0, 0, 1);
                soundPool.play(sound4, 1.0f, 1.0f, 0, 0, 1);
            }else if((soundSelect3==0)&&(soundSelect4==1)) {
                soundPool.play(sound3, 1.0f, 1.0f, 0, 0, 1);
                startPlay();//録音鳴らす
            }else if((soundSelect3==1)&&(soundSelect4==0)) {
                soundPool.play(sound4, 1.0f, 1.0f, 0, 0, 1);
                startPlay();//録音鳴らす
            }else if((soundSelect3==1)&&(soundSelect4==1)) {
                startPlay();//録音鳴らす
            }
        }
        else if(id.contains("f19")){ //10f5f19
            if(soundSelect1==0)
                soundPool.play(sound1, 1.0f, 1.0f, 0, 0, 1);
            else
                startPlay();//録音鳴らす
        }
        else if(id.contains("efc")){ //10F5EFC
            if(soundSelect2==0)
                soundPool.play(sound2, 1.0f, 1.0f, 0, 0, 1);
            else
                startPlay();//録音鳴らす
        }
        else if(id.contains("f0e")){ //10f5df9
            if(soundSelect3==0)
                soundPool.play(sound3, 1.0f, 1.0f, 0, 0, 1);
            else
                startPlay();//録音鳴らす
        }
        else if(id.contains("df9")){ //10f5f0e
            if(soundSelect4==0)
                soundPool.play(sound4, 1.0f, 1.0f, 0, 0, 1);
            else
                startPlay();//録音鳴らす
        }else{
            ;
        }
    }


    //録音
    private MediaRecorder mediarecorder; //録音用のメディアレコーダークラス

    static final String filePath = Environment.getExternalStorageDirectory() + "/sample.wav"; //録音用のファイルパス

    private void startMediaRecord(){

        try{
            File mediafile = new File(filePath);
            if(mediafile.exists()) {
                //ファイルが存在する場合は削除する
                mediafile.delete();
            }
            mediafile = null;
            mediarecorder = new MediaRecorder();
            //マイクからの音声を録音する
            mediarecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            //ファイルへの出力フォーマット DEFAULTにするとwavが扱えるはず
            mediarecorder.setOutputFormat(MediaRecorder.OutputFormat.DEFAULT);
            //音声のエンコーダーも合わせてdefaultにする
            mediarecorder.setAudioEncoder(MediaRecorder.AudioEncoder.DEFAULT);
            //ファイルの保存先を指定
            mediarecorder.setOutputFile(filePath);
            //録音の準備をする
            mediarecorder.prepare();
            //録音開始
            mediarecorder.start();
            //Toast.makeText(MainActivity.this, "Start", Toast.LENGTH_SHORT).show();
        } catch(Exception e){
            e.printStackTrace();
        }
    }


    //停止
    private void stopRecord(){
        if(mediarecorder == null){
            Toast.makeText(navigationActivity.this, "mediarecorder = null", Toast.LENGTH_SHORT).show();
        }else{
            try{
                //録音停止
                mediarecorder.stop();
                mediarecorder.reset();
                mediarecorder.release();
                //Toast.makeText(MainActivity.this, "End", Toast.LENGTH_SHORT).show();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    private MediaPlayer mp; //再生用のメディアレコーダークラス

    private  void startPlay(){
        try {
            mp = new MediaPlayer();
            mp.setDataSource(filePath);
            mp.prepare();
            mp.start();
        }catch (Exception e){
            e.printStackTrace();
        }
    }


    @Override
    protected void onPause() {//戻ったときに音解放
        super.onPause();
        soundPool.release();
    }


    // 許可の確認
    private  void checkMultiPermissions(){
        int permissionExtREAD = ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE);
        int permissionExtWRITE = ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int permissionRECORD = ContextCompat.checkSelfPermission(this,
                Manifest.permission.RECORD_AUDIO);

        List<String> reqPermissions = new ArrayList<>();

        // permission が許可されているか確認
        if (permissionExtREAD == PackageManager.PERMISSION_GRANTED) {
            isAllowedExternalRead = true;
            Log.d("debug","permissionLocation:GRANTED");
        }
        else{
            reqPermissions.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (permissionExtWRITE == PackageManager.PERMISSION_GRANTED) {
            isAllowedExternalWrite = true;
            Log.d("debug","permissionExtStorage:GRANTED");
        }
        else{
            reqPermissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (permissionRECORD == PackageManager.PERMISSION_GRANTED) {
            isAllowedRecord = true;
            Log.d("debug","permissionExtStorage:GRANTED");
        }
        else{
            reqPermissions.add(Manifest.permission.RECORD_AUDIO);
        }
        if (!reqPermissions.isEmpty()) {
            ActivityCompat.requestPermissions(this,
                    reqPermissions.toArray(new String[reqPermissions.size()]),
                    REQUEST_MULTI_PERMISSIONS);
        }
        else{
            //startLocationActivity();
        }
    }

    // 結果の受け取り
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions, @NonNull int[] grantResults) {

        if (requestCode == REQUEST_MULTI_PERMISSIONS) {
            if (grantResults.length > 0) {
                for (int i = 0; i < permissions.length; i++) {
                    if (permissions[i].
                            equals(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                        if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                            isAllowedExternalWrite = true;
                        } else {
                            // それでも拒否された時の対応
                            Toast toast = Toast.makeText(this,
                                    "外部書込の許可がないので書き込みできません", Toast.LENGTH_SHORT);
                            toast.show();
                        }
                    } else if (permissions[i].
                            equals(Manifest.permission.READ_EXTERNAL_STORAGE)) {
                        if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                            isAllowedExternalRead = true;
                        } else {
                            // それでも拒否された時の対応
                            Toast toast = Toast.makeText(this,
                                    "外部読み込みの許可がないので読み込みできません", Toast.LENGTH_SHORT);
                            toast.show();
                        }
                    } else if (permissions[i].
                            equals(Manifest.permission.RECORD_AUDIO)) {
                        if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                            isAllowedRecord = true;
                        } else {
                            // それでも拒否された時の対応
                            Toast toast = Toast.makeText(this,
                                    "録音の許可がないので録音できません", Toast.LENGTH_SHORT);
                            toast.show();
                        }
                    }
                }

            }
        }
    }
}
