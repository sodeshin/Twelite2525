package com.tocos_wireless.twe_gmonitor;


import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.hardware.usb.UsbManager;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import jp.ksksue.driver.serial.FTDriver;


public class Title extends Activity {
    Button mRC,mMole,btnBegin,btnEnd;
    FTDriver mSerial;
    private TextView mText;

    // [FTDriver] Permission String
    private static final String ACTION_USB_PERMISSION =
            "jp.ksksue.tutorial.USB_PERMISSION";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // タイトルを非表示にします。
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        // title.xmlをViewに指定します。
        setContentView(R.layout.title);

        btnBegin = (Button) findViewById(R.id.btnBegin);
        btnEnd = (Button) findViewById(R.id.btnEnd);
        mRC = (Button) findViewById(R.id.RC);
        mMole = (Button) findViewById(R.id.Mole);

        mText = (TextView) findViewById(R.id.textView1);

        mRC.setEnabled(false);
        mMole.setEnabled(false);
        btnEnd.setEnabled(false);

        // [FTDriver] Create Instance
        mSerial = new FTDriver((UsbManager)getSystemService(Context.USB_SERVICE));

        // [FTDriver] setPermissionIntent() before begin()
        PendingIntent permissionIntent = PendingIntent.getBroadcast(this, 0, new Intent(
                ACTION_USB_PERMISSION), 0);
        mSerial.setPermissionIntent(permissionIntent);




        mRC.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent=new Intent(Title.this,  navigationActivity.class);
                startActivity(intent);
            }});

        mMole.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent=new Intent(Title.this,  rhythmActivity.class);
                startActivity(intent);
            }});
    }

    @Override
    public void onBackPressed() {//backボタン無効
        //finish();
    }

    public void onBeginClick(View view) {
        // [FTDriver] Open USB Serial
        if(mSerial.begin(FTDriver.BAUD115200)) {

            mRC.setEnabled(true);
            mMole.setEnabled(true);
            btnEnd.setEnabled(true);
            btnBegin.setEnabled(false);



            mText.setText("接続中");
            mText.setTextColor(Color.BLUE);
        } else {
            mText.setText("未接続");
            mText.setTextColor(Color.RED);
        }
    }

    public void onEndClick(View view) {

        mRC.setEnabled(false);
        mMole.setEnabled(false);

        btnEnd.setEnabled(false);
        btnBegin.setEnabled(true);
        mSerial.end();
        mText.setText("未接続");
        mText.setTextColor(Color.RED);

    }}
