package com.tocos_wireless.twe_gmonitor;
import android.content.Intent;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

import android.app.PendingIntent;
import android.content.Context;
import android.hardware.usb.UsbManager;
import jp.ksksue.driver.serial.FTDriver;

public class rhythmActivity extends ActionBarActivity {
    private Button[][] mButton = new Button[2][2]; // [行][列]
    private Button mMoleButton;
    private TextView mScoreText;
    private int mScore;
    private TextView mTimeText;
    private int mGameTime = 30;
    private Timer mTimer = null;
    private Handler mHandler = new Handler();
    private RelativeLayout mGameStart,mGameOver;
    private SoundPool mSound;
    private int[] mSoundId;
    private Timer mMoleTimer = null;
    private TextView mReplayText,mStartText;
    private boolean mStop = false;
    int row,col;
    String strScore;

    FTDriver mSerial;
    final int SERIAL_BAUDRATE = FTDriver.BAUD115200;
    // [FTDriver] Permission String
    private static final String ACTION_USB_PERMISSION =
            "jp.ksksue.tutorial.USB_PERMISSION";
    private boolean mRunningMainLoop;
    private Handler myHandler,pHandler,myHandler2;
    private Runnable myTask,pTask,myTask2;

    private static final int REQUEST_MULTI_PERMISSIONS = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rhythm);

        mSoundId = new int[2];
        mSound = new SoundPool(mSoundId.length, AudioManager.STREAM_MUSIC, 0);
        mSoundId[0] = mSound.load(getApplicationContext(), R.raw.eyeshine1, 0);
        mSoundId[1] = mSound.load(getApplicationContext(), R.raw.boyon, 0);

        mMoleButton = null;
        mScore = 0;
        mScoreText = (TextView) findViewById(R.id.score);
        mTimeText = (TextView) findViewById(R.id.timeText);
        mGameOver = (RelativeLayout) findViewById(R.id.game_over_container);
        mGameOver.setOnClickListener(mGameOverClicked);
        mGameStart = (RelativeLayout) findViewById(R.id.game_start_container);
        //mGameStart.setOnClickListener(mGameStartClicked);
        mReplayText = (TextView) findViewById(R.id.replay_text);
        mStartText = (TextView) findViewById(R.id.start_text);

        mButton[0][0] = (Button) findViewById(R.id.Button1A);
        mButton[0][1] = (Button) findViewById(R.id.Button1B);

        mButton[1][0] = (Button) findViewById(R.id.Button2A);
        mButton[1][1] = (Button) findViewById(R.id.Button2B);


        /*for (int row = 0; row < mButton.length; row++) {
            for (int col = 0; col < mButton[1].length; col++) {
                mButton[row][col].setOnClickListener(mButtonClicked);
            }
        }*/



        //currentTime = 0;
        mSerial = new FTDriver((UsbManager) getSystemService(Context.USB_SERVICE));

        // [FTDriver] setPermissionIntent() before begin()
        PendingIntent permissionIntent = PendingIntent.getBroadcast(this, 0, new Intent(
                ACTION_USB_PERMISSION), 0);
        mSerial.setPermissionIntent(permissionIntent);

        mGameStart.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //myHandler.postDelayed(myTask, 100);
                //myHandler3.postDelayed(myTask3, 100);
                //mStop = false;
                if (mSerial.begin(SERIAL_BAUDRATE)) {

                    mGameStart.setVisibility(View.INVISIBLE);

                    mStop = false;
                    gameStart();
                    mainloop();

                    //start.setEnabled(false);
                    //stop.setEnabled(true);
                }
            }
        });


    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        // Inflate the menu; this adds items to the action bar if it is present.
        return true;
    }

    private void gameStart() {
        mReplayText.setVisibility(View.INVISIBLE);
        printMole();

        if (mTimer != null) {
            return;
        }
        mTimer = new Timer(true);
        mTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        mGameTime--;
                        if (mGameTime <= 0) {
                            gameOver();
                        }
                        mTimeText.setText(Integer.toString(mGameTime));
                    }
                });
            }
        }, 1000, 1000);
    }

    private void gameOver() {
        mTimer.cancel();
        mTimer = null;
        mMoleTimer.cancel();
        mMoleTimer = null;
        mGameOver.setVisibility(View.VISIBLE);


        //センサーからの入力を無効に

        //mSerial.begin(FTDriver.BAUD300);//接続をいったん切って音を消す

        Timer timer = new Timer(true);
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        mReplayText.setVisibility(View.VISIBLE);
                        strScore = String.valueOf(mScore);
                        mScoreText.setText(strScore);
                    }
                });
            }
        }, 2000);
    }

    @Override
    protected void onResume() {
        super.onResume();
        //gameStart();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mSound.release();
    }

    private void printMole() {
        if (mMoleButton != null) {
            mMoleButton.setBackgroundResource(R.drawable.bg_button);
        }
        row = (int) (Math.random() * 2);
        col = (int) (Math.random() * 2);
        mButton[row][col].setBackgroundResource(R.drawable.mole);
        mMoleButton = mButton[row][col];

        if (mMoleTimer != null) {
            mMoleTimer.cancel();
        }
        long delay = (long) (Math.random() * (1000 - 300) + 200);//ひっこめる時間
        mMoleTimer = new Timer(true);
        mMoleTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        printMole();
                    }
                });
            }
        }, delay);
    }
/*
    private View.OnClickListener mButtonClicked = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if (view != mMoleButton) {
                mSound.play(mSoundId[1], 1.0F, 1.0F, 0, 0, 1.0F);
                mScore--;//ミスしたら減点
                String strScore = String.valueOf(mScore);
                mScoreText.setText(strScore);
                return;
            }
            mSound.play(mSoundId[0], 1.0F, 1.0F, 0, 0, 1.0F);
            mScore++;
            String strScore = String.valueOf(mScore);
            mScoreText.setText(strScore);
            printMole();//タップ無効か
        }
    };*/

    private View.OnClickListener mGameOverClicked = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if (mReplayText.getVisibility() != View.VISIBLE) {
                return;
            }
            mGameOver.setVisibility(View.INVISIBLE);
            mScore = 0;
            String strScore = String.valueOf(mScore);
            mScoreText.setText(strScore);
            mGameTime = 30;
            //gameStart();
            Intent intent=new Intent(rhythmActivity.this,  Title.class);//////
            startActivity(intent);
        }
    };
/*
    private View.OnClickListener mGameStartClicked = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            mGameStart.setVisibility(View.INVISIBLE);

            gameStart();


        }
    };*/

    private void mainloop() {
        mRunningMainLoop = true;
        new Thread(mLoop).start();
    }

    private Runnable mLoop = new Runnable() {
        @Override
        public void run() {

            int i, len;

            // [FTDriver] Create Read Buffer

            while (true) {
                byte[] rbuf = new byte[4096]; // 1byte <--slow-- [Transfer Speed] --fast--> 4096 byte
                // [FTDriver] Read from USB serial
                len = mSerial.read(rbuf);
                rbuf[len] = 0;
                String str1 = new String(rbuf);


                if (len > 36) {

                    String[] new_str1 = str1.split(";", 0);

                    if (mGameTime <= 0) {
                        break;
                    }
                    Punch(str1);
                }

            }
        }
    };

    private  void Punch(String id){
        if(id.contains("f19")){ //10f5f19
            if((row==0)&&(col==0))
                Score(1);
            else
                Score(2);
        }
        else if(id.contains("efc")){ //10F5EFC
            if((row==0)&&(col==1))
                Score(1);
            else
                Score(2);
        }
        else if(id.contains("f0e")){ //10f5df9
            if((row==1)&&(col==0))
                Score(1);
            else
                Score(2);
        }
        else if(id.contains("df9")){ //10f5f0e
            if((row==1)&&(col==1))
                Score(1);
            else
                Score(2);

        }

    }

    public  void Score(int id){
        if(id==2) {
            mSound.play(mSoundId[1], 1.0F, 1.0F, 0, 0, 1.0F);
            mScore--;//ミスしたら減点
            //strScore = String.valueOf(mScore);
            //mScoreText.setText(strScore);
            return;
        }
            mSound.play(mSoundId[0], 1.0F, 1.0F, 0, 0, 1.0F);
            mScore++;
            //strScore = String.valueOf(mScore);
            //mScoreText.setText(strScore);
            //printMole();

    }


    @Override
    public void onBackPressed() {//backボタン無効
        //super.onBackPressed();
    }
}